<?php
//Start session
session_start();

$session_id=$_SESSION['g_ID'];

?>